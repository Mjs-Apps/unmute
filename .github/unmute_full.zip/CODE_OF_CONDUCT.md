# Code of Conduct
Be kind. Assume good intent. No harassment, hate speech, or discrimination. Respect lived experience and accessibility needs. Violations may result in blocked participation.
